
# PayrollAutomation Canonical Starter

This package organizes your existing modules into a predictable structure and adds small wrapper scripts and a single orchestrator.

## Folders

- modules/ : your .psm1 modules (copied from your zip)
- scripts/ : small wrappers that read config and call modules
- config/appsettings.json : update paths + SQL once

## Usage

1. Copy this entire folder to `C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\`.
2. Put your working `Payroll.xlsx` alongside (same folder).
3. Update `config\appsettings.json` (WorkbookPath, SQL, etc).
4. Open PowerShell and run:

```
cd C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_ClearConsolidation.ps1 -ConfigPath .\config\appsettings.json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_TransformPayroll.ps1 -ConfigPath .\config\appsettings.json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_AddCalculatedColumns.ps1 -ConfigPath .\config\appsettings.json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_AddPayrollMonth.ps1 -ConfigPath .\config\appsettings.json -PayrollMonth 2025-08
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_BuildOutput.ps1 -ConfigPath .\config\appsettings.json
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_InsertToSQL.ps1 -ConfigPath .\config\appsettings.json
```

Or one-shot:
```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Payroll_Orchestrator.ps1 -ConfigPath .\config\appsettings.json -PayrollMonth 2025-08
```

## IMPORTANT: ImportExcel module

Some modules depend on `ImportExcel`. If installing from the gallery is blocked, vendor the module:

- Download "ImportExcel" module (version 7.8.6 or similar) on a machine with internet.
- Copy the folder `ImportExcel` into `modules\vendor\ImportExcel\`.
- Add this at the **top** of any module that calls Import-Excel/Export-Excel:

```
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$vendor = Join-Path $here "vendor\ImportExcel\ImportExcel.psd1"
if (Test-Path $vendor) { Import-Module $vendor -Force }
```

This avoids admin rights and online installs.

## PAD

In PAD, each "Run PowerShell script" action should call the wrapper in `scripts/` with:
- `-ExecutionPolicy Bypass`
- `-File` set to the wrapper script
- `-ConfigPath` = full path to `config\appsettings.json`
- For the "Add Payroll Month" step also pass `-PayrollMonth yyyy-MM`.

