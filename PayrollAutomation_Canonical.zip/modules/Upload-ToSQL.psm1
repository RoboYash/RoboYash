<#
.SYNOPSIS
    Uploads the final payroll data from Excel to a SQL Server table.

.DESCRIPTION
    This module reads payroll data from the processed Excel sheet
    and inserts it into a SQL Server table.
    Requires SQL connectivity and the table to be already created.

.PARAMETER ExcelPath
    Path to the payroll Excel file.

.PARAMETER OutputSheet
    Sheet name containing the processed payroll data.

.PARAMETER SqlConnectionString
    SQL Server connection string.

.PARAMETER SqlTableName
    Target SQL Server table name.
#>

function Upload-ToSQL {
    param(
        [string]$ExcelPath,
        [string]$OutputSheet,
        [string]$SqlConnectionString,
        [string]$SqlTableName
    )

    Write-Host "Uploading data from Excel ($ExcelPath - Sheet: $OutputSheet) to SQL Table: $SqlTableName ..."

    # Load Excel COM object
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $workbook = $excel.Workbooks.Open($ExcelPath)
    $worksheet = $workbook.Sheets.Item($OutputSheet)

    # Find the last row and column
    $lastRow = $worksheet.Cells.Find("*", $worksheet.Cells.Item(1,1),
                    [Type]::Missing, [Type]::Missing,
                    [Microsoft.Office.Interop.Excel.XlSearchOrder]::xlByRows,
                    [Microsoft.Office.Interop.Excel.XlSearchDirection]::xlPrevious,
                    $false).Row
    $lastColumn = $worksheet.Cells.Find("*", $worksheet.Cells.Item(1,1),
                    [Type]::Missing, [Type]::Missing,
                    [Microsoft.Office.Interop.Excel.XlSearchOrder]::xlByColumns,
                    [Microsoft.Office.Interop.Excel.XlSearchDirection]::xlPrevious,
                    $false).Column

    # Read header row (column names)
    $headers = @()
    for ($col = 1; $col -le $lastColumn; $col++) {
        $headers += $worksheet.Cells.Item(1, $col).Text
    }

    # Read each data row into objects
    $data = @()
    for ($row = 2; $row -le $lastRow; $row++) {
        $rowObj = @{}
        for ($col = 1; $col -le $lastColumn; $col++) {
            $header = $headers[$col - 1]
            $rowObj[$header] = $worksheet.Cells.Item($row, $col).Text
        }
        $data += (New-Object PSObject -Property $rowObj)
    }

    # Close Excel
    $workbook.Close($false)
    $excel.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null

    # Connect to SQL
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $SqlConnectionString
    $connection.Open()

    foreach ($row in $data) {
        # Build dynamic INSERT statement
        $columns = ($headers -join ",")
        $values  = ($headers | ForEach-Object { "'" + ($row.$_ -replace "'", "''") + "'" }) -join ","
        $query = "INSERT INTO $SqlTableName ($columns) VALUES ($values)"

        $command = $connection.CreateCommand()
        $command.CommandText = $query
        $command.ExecuteNonQuery() | Out-Null
    }

    $connection.Close()

    Write-Host "Data successfully uploaded to SQL table: $SqlTableName"
}