function Add-PayrollMonthColumn {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ExcelPath,
        [string]$InputSheet = "FinalOutput",
        [string]$OutputSheet = "FinalOutputWithMonth",
        [Parameter(Mandatory = $true)]
        [string]$PayrollMonth
    )

    # Import Excel module
    Import-Module ImportExcel -ErrorAction Stop

    Write-Host "Reading data from $InputSheet..."
    $data = Import-Excel -Path $ExcelPath -WorksheetName $InputSheet

    Write-Host "Adding Payroll Month column..."
    $data | ForEach-Object {
        $_ | Add-Member -NotePropertyName "PayrollMonth" -NotePropertyValue $PayrollMonth -PassThru
    }

    Write-Host "Writing data with Payroll Month to $OutputSheet..."
    $data | Export-Excel -Path $ExcelPath -WorksheetName $OutputSheet -AutoSize -ClearSheet

    Write-Host "AddPayrollMonthColumn completed."
}