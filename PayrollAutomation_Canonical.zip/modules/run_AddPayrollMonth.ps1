param(
  [Parameter(Mandatory=$true)][string]$WorkbookPath,
  [Parameter(Mandatory=$true)][string]$PayrollMonth,
  [switch]$Overwrite
)

Import-Module -Force -Name (Join-Path $PSScriptRoot 'PayrollAutomation.impl.psm1')

$result = Add-PayrollMonthColumn -WorkbookPath $WorkbookPath -PayrollMonth $PayrollMonth -Overwrite:$Overwrite
$result