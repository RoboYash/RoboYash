<#
.SYNOPSIS
    Main automation pipeline for Payroll Processing.

.DESCRIPTION
    This module orchestrates the entire payroll process step-by-step:
        1. Clear Consolidation sheet
        2. Transform table using map
        3. Add Payroll Month column
        4. Add calculated columns
        5. Consolidate data
        6. Upload final consolidated data into SQL Server (Upload-ToSQL)
        7. Export processed data from SQL Server into Excel report (Export-FromSQL)

.NOTES
    Author: Payroll Automation Project
#>

# Import all sub-modules
Import-Module "$PSScriptRoot\Clear-Consolidation.impl.psm1" -Force
Import-Module "$PSScriptRoot\TransformTableUsingMap.psm1" -Force
Import-Module "$PSScriptRoot\Add-PayrollMonthColumn.psm1" -Force
Import-Module "$PSScriptRoot\Add-CalculatedColumnToOutput.psm1" -Force
#Import-Module "$PSScriptRoot\Upload-ToSQL.psm1" -Force
#Import-Module "$PSScriptRoot\Export-FromSQL.psm1" -Force

function Run-PayrollAutomation {
    param (
        [string]$InputFilePath = "C:\IMVP64-Payroll_File_Consolidation\Input\Payroll_Input.xlsx",
        [string]$ConsolidationFilePath = "C:\IMVP64-Payroll_File_Consolidation\Output\Payroll_Consolidated.xlsx",
        [string]$SqlServer = "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS",
        [string]$Database = "WizzAir.GTN-RAW",
        [string]$TableName = "PayrollData",
        [string]$ExportPath = "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll_Report.xlsx"
    )

    Write-Output "========== Starting Payroll Automation =========="

    # 1. Clear Consolidation
    Clear-Consolidation -ConsolidationFilePath $ConsolidationFilePath

    # 2. Transform table using map
    TransformTableUsingMap -InputFilePath $InputFilePath -ConsolidationFilePath $ConsolidationFilePath

    # 3. Add Payroll Month column
    Add-PayrollMonthColumn -FilePath $ConsolidationFilePath

    # 4. Add calculated columns
    Add-CalculatedColumnToOutput -FilePath $ConsolidationFilePath

    # 5. Upload to SQL
    Upload-ToSQL -SqlServer $SqlServer -Database $Database -TableName $TableName -ExcelFilePath $ConsolidationFilePath

    # 6. Export from SQL (report)
    Export-FromSQL -SqlServer $SqlServer -Database $Database -TableName $TableName -ExportPath $ExportPath

    Write-Output "========== Payroll Automation Completed =========="
    Write-Output "Report generated at: $ExportPath"
}

Export-ModuleMember -Function Run-PayrollAutomation