function Export-FromSQL {
    param (
        [string]$SqlServer = "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS",
        [string]$Database = "WizzAir.GTN-RAW",
        [string]$TableName = "PayrollData",
        [string]$ExportPath = "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll_Report.xlsx"
    )

    Write-Output "Exporting payroll data from SQL table: $TableName"

    # SQL Query
    $Query = "SELECT * FROM [$TableName]"

    # Connection string
    $ConnectionString = "Server=$SqlServer;Database=$Database;Integrated Security=True;"

    # Load SQL data
    $DataTable = New-Object System.Data.DataTable
    $Connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $Command = New-Object System.Data.SqlClient.SqlCommand $Query, $Connection
    $Adapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command

    $Adapter.Fill($DataTable) | Out-Null
    $Connection.Close()

    # Export to Excel
    if (Test-Path $ExportPath) { Remove-Item $ExportPath } # overwrite if exists
    $excel = New-Object -ComObject Excel.Application
    $workbook = $excel.Workbooks.Add()
    $worksheet = $workbook.Worksheets.Item(1)

    # Write headers
    for ($col = 0; $col -lt $DataTable.Columns.Count; $col++) {
        $worksheet.Cells.Item(1, $col + 1) = $DataTable.Columns[$col].ColumnName
    }

    # Write rows
    for ($row = 0; $row -lt $DataTable.Rows.Count; $row++) {
        for ($col = 0; $col -lt $DataTable.Columns.Count; $col++) {
            $worksheet.Cells.Item($row + 2, $col + 1) = $DataTable.Rows[$row][$col]
        }
    }

    # Save Excel
    $workbook.SaveAs($ExportPath)
    $excel.Quit()

    Write-Output "Report exported successfully to: $ExportPath"
}

Export-ModuleMember -Function Export-FromSQL