param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$PayrollMonth
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$run = Join-Path $root "scripts"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_ClearConsolidation.ps1") -ConfigPath $ConfigPath
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_TransformPayroll.ps1") -ConfigPath $ConfigPath
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_AddCalculatedColumns.ps1") -ConfigPath $ConfigPath
if (-not $PayrollMonth) { $PayrollMonth = (Get-Date).ToString("yyyy-MM") }
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_AddPayrollMonth.ps1") -ConfigPath $ConfigPath -PayrollMonth $PayrollMonth
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_BuildOutput.ps1") -ConfigPath $ConfigPath
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_InsertToSQL.ps1") -ConfigPath $ConfigPath -OutputSheet "FinalOutputWithMonth"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $run "run_Validate.ps1") -ConfigPath $ConfigPath | Tee-Object -Variable validation
Write-Host "Validation:" $validation
