param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
Import-Module "$PSScriptRoot\..\modules\TransformTableUsingMap.psm1" -Force
Transform-TableUsingMap -ExcelPath $cfg.WorkbookPath
