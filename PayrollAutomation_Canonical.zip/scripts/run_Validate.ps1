param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$Mode = "post-run",
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
# Minimal validation: ensure sheets exist and have rows
$path = $cfg.WorkbookPath
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$wb = $excel.Workbooks.Open($path)
function CountRows($wb, $sheetName) {
    $ws = $wb.Worksheets.Item($sheetName)
    $used=$ws.UsedRange
    return $used.Rows.Count
}
$report = [ordered]@{}
foreach ($s in @("Munka1","Consolidation","Transformed","FinalOutput","FinalOutputWithMonth")) {
    try {$report[$s]=CountRows $wb $s} catch { $report[$s]="MISSING" }
}
$wb.Close($false); $excel.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
$report | ConvertTo-Json
