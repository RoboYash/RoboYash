param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [Parameter(Mandatory=$true)][string]$PayrollMonth,
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
Import-Module "$PSScriptRoot\..\modules\Add-PayrollMonthColumn.psm1" -Force
Add-PayrollMonthColumn -ExcelPath $cfg.WorkbookPath -InputSheet "FinalOutput" -OutputSheet "FinalOutputWithMonth" -PayrollMonth $PayrollMonth
