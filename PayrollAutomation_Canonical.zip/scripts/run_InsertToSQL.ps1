param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$OutputSheet = "FinalOutputWithMonth",
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json

# Build connection string
if ($cfg.Sql.Auth -eq "Integrated") {
  $conn = "Server={0};Database={1};Trusted_Connection=True;" -f $cfg.Sql.Server, $cfg.Sql.Database
} else {
  throw "Only Integrated auth is modeled here. Update run_InsertToSQL.ps1 for SQL auth."
}
Import-Module "$PSScriptRoot\..\modules\Upload-ToSQL.psm1" -Force
Upload-ToSQL -ExcelPath $cfg.WorkbookPath -OutputSheet $OutputSheet -SqlConnectionString $conn -SqlTableName $cfg.Sql.Table
