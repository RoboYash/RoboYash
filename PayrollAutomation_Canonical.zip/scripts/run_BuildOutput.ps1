param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
Import-Module "$PSScriptRoot\..\modules\Build-OutputSheet.psm1" -Force
New-PayrollOutput -ExcelPath $cfg.WorkbookPath -SourceSheet "FinalOutputWithMonth"
