param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
Import-Module "$PSScriptRoot\..\modules\Add-CalculatedColumnToOutput.psm1" -Force
Add-CalculatedColumnToOutput -ExcelPath $cfg.WorkbookPath -InputSheet "Transformed" -OutputSheet "FinalOutput"
