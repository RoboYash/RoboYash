param(
  [Parameter(Mandatory=$true)][string]$ConfigPath,
  [string]$LogFolder = ""
)
$ErrorActionPreference = "Stop"
$cfg = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
Import-Module "$PSScriptRoot\..\modules\Clear-Consolidation.impl.psm1" -Force
Write-Host "Clearing Consolidation in $($cfg.WorkbookPath)"
Clear-ConsolidationSheet -WorkbookPath $cfg.WorkbookPath
