function Transform-TableUsingMap {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ExcelPath
    )

    # Import Excel module
    Import-Module ImportExcel -ErrorAction Stop

    Write-Host "Transforming table using map on: $ExcelPath"

    # 1️⃣ Load mapping table
    $mappingSheet = "Mapping"
    $mapping = Import-Excel -Path $ExcelPath -WorksheetName $mappingSheet

    # Convert mapping table to hashtable
    $mapDict = @{}
    foreach ($row in $mapping) {
        if ($row.SourceColumn -and $row.TargetColumn) {
            $mapDict[$row.SourceColumn] = $row.TargetColumn
        }
    }

    # 2️⃣ Read source data
    $sourceSheet = "Consolidation"
    $sourceData = Import-Excel -Path $ExcelPath -WorksheetName $sourceSheet

    # 3️⃣ Transform rows using mapping
    $transformedData = @()
    foreach ($row in $sourceData) {
        $newRow = @{}
        foreach ($col in $row.PSObject.Properties.Name) {
            if ($mapDict.ContainsKey($col)) {
                $newRow[$mapDict[$col]] = $row.$col
            }
            else {
                # Optional: keep unmapped columns
                $newRow[$col] = $row.$col
            }
        }
        $transformedData += New-Object PSObject -Property $newRow
    }

    # 4️⃣ Ensure Transformed sheet always exists
    $outputSheet = "Transformed"

    # Clear old sheet if exists
    if (Get-ExcelSheetInfo -Path $ExcelPath | Where-Object Name -eq $outputSheet) {
        Write-Host "Clearing existing Transformed sheet..."
        $null = Export-Excel -Path $ExcelPath -WorksheetName $outputSheet -ClearSheet
    }

    # Export transformed data
    Write-Host "Writing data to Transformed sheet..."
    $transformedData | Export-Excel -Path $ExcelPath -WorksheetName $outputSheet -AutoSize -TableName $outputSheet -ClearSheet

    Write-Host "Transformation complete. Transformed sheet is ready!"
}