function Add-CalculatedColumnToOutput {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ExcelPath,
        [string]$InputSheet = "Transformed",
        [string]$OutputSheet = "FinalOutput"
    )

    # Import Excel module
    Import-Module ImportExcel -ErrorAction Stop

    Write-Host "Reading transformed data from $InputSheet..."
    $data = Import-Excel -Path $ExcelPath -WorksheetName $InputSheet

    Write-Host "Adding calculated columns..."

    $calculatedData = $data | ForEach-Object {
        # Ensure Deductions column exists; if not, default to 0
        if (-not $_.PSObject.Properties.Match("Deductions")) {
            $_ | Add-Member -NotePropertyName "Deductions" -NotePropertyValue 0 -PassThru
        }

        $_ | Add-Member -NotePropertyName "TotalCompensation" -NotePropertyValue ( ($_.Base_Salary + $_.Bonus_Amount) ) -PassThru
        $_ | Add-Member -NotePropertyName "NetPay" -NotePropertyValue ( ($_.Base_Salary + $_.Bonus_Amount) - ($_.Deductions -as [decimal] ) ) -PassThru
        $_
    }

    Write-Host "Writing data with calculated columns to $OutputSheet..."
    $calculatedData | Export-Excel -Path $ExcelPath -WorksheetName $OutputSheet -AutoSize -ClearSheet

    Write-Host "AddCalculatedColumnToOutput completed."
}