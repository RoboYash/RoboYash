param(
    [Parameter(Mandatory=$true)][string]$WorkbookPath
)

# Import your module
Import-Module -Force -Name (Join-Path $PSScriptRoot 'Clear-Consolidation.impl.psm1')

# Run the function
Clear-ConsolidationSheet -WorkbookPath $WorkbookPath
  