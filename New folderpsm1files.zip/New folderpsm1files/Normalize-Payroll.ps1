param(
    [string]$ExcelPath = "C:\path\Payroll.xlsx",
    [string]$SourceSheet = "Munka1",
    [string]$MappingSheet = "Mapping",
    [string]$ConsolidationSheet = "Consolidation"
)

# Ensure ImportExcel is installed
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber
}

# Read mapping sheet
$mapRows = Import-Excel -Path $ExcelPath -WorksheetName $MappingSheet
$mapping = @{}
foreach ($r in $mapRows) {
    if ($r.SourceColumn -and $r.StandardColumn) {
        $mapping[$r.SourceColumn.Trim()] = $r.StandardColumn.Trim()
    }
}

# Read source data
$rows = Import-Excel -Path $ExcelPath -WorksheetName $SourceSheet

# Transform headers using mapping
$outRows = foreach ($row in $rows) {
    $props = [ordered]@{}
    foreach ($p in $row.PSObject.Properties) {
        $srcName = $p.Name.Trim()
        $stdName = if ($mapping.ContainsKey($srcName)) { $mapping[$srcName] } else { $srcName }
        $props[$stdName] = $p.Value
    }
    New-Object PSObject -Property $props
}

# Try reading consolidation
$existing = $null
try {
    $existing = Import-Excel -Path $ExcelPath -WorksheetName $ConsolidationSheet -ErrorAction Stop
} catch {
    # sheet not present -> will be created
}

if ($existing) {
    # Merge with existing rows
    $combined = @()
    $combined += $existing
    $combined += $outRows
    $combined | Export-Excel -Path $ExcelPath -WorksheetName $ConsolidationSheet -AutoSize -ClearSheet
} else {
    # Create new consolidation sheet
    $outRows | Export-Excel -Path $ExcelPath -WorksheetName $ConsolidationSheet -AutoSize
}

Write-Host "✅ Done. Merged $($outRows.Count) rows from '$SourceSheet' into '$ConsolidationSheet'."