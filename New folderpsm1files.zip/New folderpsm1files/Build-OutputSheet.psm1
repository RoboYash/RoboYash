# Build-OutputSheet.psm1
# Creates an 'Output' sheet matching the IMVP64 workbook's Output structure.
# Reads from FinalOutputWithMonth + optional config sheets and computes many fields.
# Missing configs default to 0 so you can evolve rates gradually.

function New-PayrollOutput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ExcelPath,

        # Name of the source sheet that already contains normalized + month columns
        [string]$SourceSheet = "FinalOutputWithMonth",

        # Optional: name of activity counts sheet (if you have one)
        [string]$ActivitySheet = "Activity_Log",

        # Output sheet name (must match your legacy target)
        [string]$OutputSheet = "Output"
    )

    #-------------------------------
    # Helpers
    #-------------------------------
    function Get-WorksheetOrNull($wb, $name) {
        foreach ($ws in $wb.Worksheets) { if ($ws.Name -eq $name) { return $ws } }
        return $null
    }
    function Get-Table($ws) {
        # Returns a 2D array [row, col] of used range
        if (-not $ws) { return @() }
        $used = $ws.UsedRange
        $rows = $used.Rows.Count
        $cols = $used.Columns.Count
        $data = @()
        for ($r=1; $r -le $rows; $r++) {
            $row = @()
            for ($c=1; $c -le $cols; $c++) { $row += $used.Item($r,$c).Text }
            $data += ,$row
        }
        return $data
    }
    function Index-By($rows, $keyName) {
        # rows: array of hashtables
        $ix = @{}
        foreach ($r in $rows) {
            if ($r.ContainsKey($keyName) -and $r[$keyName] -ne "") {
                $ix[$r[$keyName]] = $r
            }
        }
        return $ix
    }
    function To-Objects($data) {
        if (-not $data -or $data.Count -lt 2) { return @() }
        $headers = $data[0]
        $objs = @()
        for ($i=1; $i -lt $data.Count; $i++) {
            $h = @{}
            for ($c=0; $c -lt $headers.Count; $c++) {
                $name = [string]$headers[$c]
                if (-not [string]::IsNullOrWhiteSpace($name)) {
                    $h[$name] = $data[$i][$c]
                }
            }
            $objs += ,$h
        }
        return $objs
    }
    function Get-DecimalOrZero($val) {
        if ($val -is [string]) { $val = $val -replace ",","." }
        [decimal]([double]::TryParse($val, [ref]([double]$null)) ? $val : 0)
    }
    function Rate($ratesIndex, $key, $default=0) {
        if ($ratesIndex.ContainsKey($key)) { return Get-DecimalOrZero $ratesIndex[$key]["ValueLocal"] }
        return $default
    }
    function SectorRate($ix, $size) {
        if ($ix.ContainsKey($size)) { return Get-DecimalOrZero $ix[$size]["RateLocal"] }
        return 0
    }
    function OfficeRate($ix, $cat) {
        $k = [string]$cat
        if ($ix.ContainsKey($k)) { return Get-DecimalOrZero $ix[$k]["RateLocal"] }
        return 0
    }
    function PerDiemForBase($ix, $base, $fxRate) {
        if ($ix.ContainsKey($base)) {
            $r = $ix[$base]
            $eur = Get-DecimalOrZero $r["Per Diem EUR"]
            $local = Get-DecimalOrZero $r["Per Diem local currency"]
            if ($local -gt 0) { return $local }
            if ($eur  -gt 0) { return [decimal]$eur * [decimal]$fxRate }
        }
        return 0
    }
    function FxRateForBase($ix, $base) {
        if ($ix.ContainsKey($base)) {
            $r = $ix[$base]
            $rate = Get-DecimalOrZero $r["RateToEUR"]
            if ($rate -gt 0) { return $rate }
        }
        return 1 # default 1.0 for EUR bases
    }

    #-------------------------------
    # Open Excel and read sheets
    #-------------------------------
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    try {
        $wb = $excel.Workbooks.Open($ExcelPath)

        $wsSrc = Get-WorksheetOrNull $wb $SourceSheet
        if (-not $wsSrc) { throw "Source sheet '$SourceSheet' not found." }
        $srcData = Get-Table $wsSrc
        $srcRows = To-Objects $srcData

        # Optional activity/metrics
        $wsAct = Get-WorksheetOrNull $wb $ActivitySheet
        $actIndex = @{}
        if ($wsAct) {
            $actRows = To-Objects (Get-Table $wsAct)
            # Choose your preferred key: EmployeeID or Name + Month + Base
            # Here we use EmployeeID if present, else Name
            foreach ($r in $actRows) {
                $k = if ($r["EmployeeID"]) { $r["EmployeeID"] } else { $r["Name"] }
                if ($k) { $actIndex[$k] = $r }
            }
        }

        # Rates sheets (all optional – default to zeros if missing)
        $ratesMiscIndex = @{}
        $wsMisc = Get-WorksheetOrNull $wb "Rates_Misc"
        if ($wsMisc) { $ratesMiscIndex = Index-By (To-Objects (Get-Table $wsMisc)) "Key" }

        $sectorRateIndex = @{}
        $wsSectors = Get-WorksheetOrNull $wb "Rates_Sectors"
        if ($wsSectors) { $sectorRateIndex = Index-By (To-Objects (Get-Table $wsSectors)) "Size" }

        $officeRateIndex = @{}
        $wsOffice = Get-WorksheetOrNull $wb "Rates_OfficeDuty"
        if ($wsOffice) { $officeRateIndex = Index-By (To-Objects (Get-Table $wsOffice)) "Category" }

        $perDiemIndex = @{}
        $wsPerDiem = Get-WorksheetOrNull $wb "Rates_PerDiem"
        if ($wsPerDiem) { $perDiemIndex = Index-By (To-Objects (Get-Table $wsPerDiem)) "Base" }

        $fxIndex = @{}
        $wsFx = Get-WorksheetOrNull $wb "ExchangeRates"
        if ($wsFx) { $fxIndex = Index-By (To-Objects (Get-Table $wsFx)) "Base" }

        #-------------------------------
        # Define exact Output columns (your list)
        #-------------------------------
        $outputColumns = @(
            "Payroll Month","EmployeeID","Name","Start date at the branch","Exit date","Company","Base","Cost center","Position","Exchange rate",
            "Base Salary, EUR/year","Base Salary, local currency/year","Monthly Base Salary, EUR","Monthly Base Salary, local currency",
            "Nr. of days on sick leave paid by employer","Nr. of days on sick leave paid by state","Sick leave pay, local currency",
            "Nr. of days on maternity leave","Maternity leave pay, local currency","Nr. of days on holiday","Holiday pay, local currency",
            "Nr. of days on other holidays","Other holiday pay, local currency","Nr. of days on unpaid leave","Nr. of days on unjustified absence",
            "Nr. of days working on public holiday","Public holiday pay, local currency","Nr. of statutory working days","Nr. of statutory working hours",
            "Nr. of actual working days","Nr. of actual working hrs","Base Salary for actual working days, local currency","Base Salary for actual working days, EUR",
            "Total base salary, local currency","Nr of S sectors","S sector pay, local currency","Nr of M sectors","M sector pay, local currency",
            "Nr of L sectors","L sector pay, local currency","Nr of XL sectors","XL sector pay, local currency","Nr of XXL sectors","XXL sector pay, local currency",
            "Nr of Office sectors","Office sector pay, local currency","Nr of Extra sectors","Extra sector pay, local currency","Total sector pay, local currency",
            "Commission, local currency","Mentoring allowance, local currency","Nr of Cabin Crew DA advance","Cabin crew DA advance pay, local currency",
            "Nr of Cabin Crew DA balance","Cabin Crew DA balance pay, local currency","Nr of Flight Crew DA","Flight Crew DA pay, local currency",
            "Nr of flown kilometres","Distance pay, local currency","Nr of landings","Landing pay, local currency",
            "Nr of office duty category 1","Office duty category 1 pay, local currency","Nr of office duty category 2","Office duty category 2 pay, local currency",
            "Nr of office duty category 3","Office duty category 3 pay, local currency","Nr of office duty category 4","Office duty category 4 pay, local currency",
            "Nr of office duty category 5","Office duty category 5 pay, local currency","Total office duty pay, local currency",
            "Nr of extra flying duties","Extra flying pay, local currency","Nr of out of base duties","Out of base duty pay, local currency",
            "Nr of line training sectors","Line training sector pay, local currency","Flexible roster allowance, local currency","Pilot loyalty bonus, local currency",
            "Night transportation pay, local currency","People council allowance, local currency","All employee bonus, local currency","Relocation support, local currency",
            "One time payment, local currency","Correction","Nr of remaining holidays","Remaining holiday payment, local currency",
            "Disrupted Roster Compensation, local currency","Nr. of flying duty days","Per Diem total, EUR","Per Diem total, local currency",
            "Daily allowance tax free, EUR","Daily allowance tax free, local currency","Commission EUR","Distance pay, EUR","Landing pay, EUR","Pilot Ranking",
            "Total Gross Salary, local currency","Total Gross Salary, EUR","Personal Income Tax, local currency","Total Employee contributions, local currency",
            "Total Employer contributions, local currency","Total employment cost, EUR","Total employment cost, local currency","Net Salary, EUR","Net Salary, local currency",
            "Net Payment, EUR","Net Payment, local currency","Total Contributions","Other Advances","NET SALARY TO BE PAID","Comments",
            "Country Manager (Office) Allowance","Seniority bonus","Interim Tax Correction, local currency","Total taxable earnings","Total non-taxable earnings",
            "Social Ins (max EUR488.49)","hun ytd march","Monthly Cyprus Tax","Yearly Up-to-Date CY tax","TAX CREDIT","tax credit v2",
            "Hungarian Tax, local currency","Hungarian Tax, EUR","Yearly Up-to-Date HUN tax","Loss of Licence, local currency","GHS","GHS Other",
            "Corrections - Tax credit","Total Deductions","S.Cohesion","Redundancy (max EUR 66.61)","Ind.Train. (max 27.76)","Other Contr","0","AC","POS","Block Hours",
            "CONTRACT TYPE","TOTAL NUMBER OF DUTY DAYS","NIGHT FLIGHT ALLOWANCE (COUNT)","NIGHT FLIGHT ALLOWANCE (EUR)","DA ADVANCED","DA advance amount","DA BALANCE",
            "TOTAL  XXL","TOTAL XL","TOTAL L","TOTAL M","TOTAL S","TOTAL","INTERNATIONAL XXL","INTERNATIONAL XL","INTERNATIONAL L","INTERNATIONAL M","INTERNATIONAL S",
            "DOMESTIC XXL","DOMESTIC XL","DOMESTIC L","DOMESTIC M","DOMESTIC S","EXTRA FLYING SECTORS","OUT OF BASE DUTY","OFFICE DUTIES","LINE TRAINING DAYS",
            "GROUND TRAINING","OFFICE SECTORS TOTAL","CREW COMMISSION","CREW COMMISSION CURRENCY","MENTORING ALLOWANCE 6 MONTH EUR","MENTORING ALLOWANCE 12 MONTH EUR",
            "TOTAL MENTORING ALLOWANCE EUR","CAPTAIN FLOWN HOURS","TOTAL KM","KM INTERNATIONAL","KM DOMESTIC","FLOWN DUTY DAYS TOTAL","TOTAL NR OF FLOWN LANDINGS",
            "OFFICE DUTY CAT 5","OFFICE DUTY CAT 4","OFFICE DUTY CAT 3","OFFICE DUTY CAT 2","OFFICE DUTY CAT 1","EXTRA FLYING DUTIES","FLYING FROM OFF / HP",
            "DAILY ALLOWANCE","LINE TRAINING SECTORS","FLOATING PILOT ALLOWANCE","PILOT LOYALTY BONUS","NIGHT FLIGHT ALLOWANCE (Count)2","LOSS OF LICENCE",
            "LOSS OF LICENCE TYPE","FLEXIBLE ROSTER","FLEXIBLE ROSTER CURRENCY","SIGN-ON BONUS","RETENTION BONUS","NUMBER OF AIRCRAFTS"
        )

        # Create/clear Output sheet
        $wsOut = Get-WorksheetOrNull $wb $OutputSheet
        if ($wsOut) { $wsOut.Cells.Clear() } else { $wsOut = $wb.Worksheets.Add(); $wsOut.Name = $OutputSheet }

        # Write headers
        for ($i=0; $i -lt $outputColumns.Count; $i++) {
            $wsOut.Cells.Item(1, $i+1) = $outputColumns[$i]
        }

        # Main row loop: build each Output line
        $rowOut = 2
        foreach ($r in $srcRows) {
            # Identity & basics
            $payrollMonth = $r["PayrollMonth"]; if (-not $payrollMonth) { $payrollMonth = $r["Payroll Month"] }
            $empId   = $r["EmployeeID"]
            $name    = $r["Employee_Name"]; if (-not $name) { $name = $r["Name"] }
            $base    = $r["Base"]; if (-not $base) { $base = $r["Department"] } # fallback if your data uses "Base" differently
            $company = $r["Company"]
            $position= $r["Position"]
            $costCtr = $r["Cost center"]

            # Currency & salaries
            $fx = FxRateForBase $fxIndex $base
            $baseSalaryLocal = Get-DecimalOrZero $r["Base_Salary"]
            $baseSalaryEUR   = [decimal]0
            if ($fx -gt 0) { $baseSalaryEUR = [decimal]$baseSalaryLocal / [decimal]$fx }

            $bonusLocal = Get-DecimalOrZero $r["Bonus_Amount"]
            $totalCompLocal = Get-DecimalOrZero $r["TotalCompensation"]; if ($totalCompLocal -eq 0) { $totalCompLocal = $baseSalaryLocal + $bonusLocal }

            # Stat/actual days/hours (if available in source or activity)
            $key = if ($empId) { $empId } else { $name }
            $act = if ($actIndex.ContainsKey($key)) { $actIndex[$key] } else { @{} }

            $statDays  = Get-DecimalOrZero $r["Nr. of statutory working days"];  if ($statDays -eq 0)  { $statDays  = Get-DecimalOrZero $act["Nr. of statutory working days"] }
            $statHours = Get-DecimalOrZero $r["Nr. of statutory working hours"];if ($statHours -eq 0) { $statHours = Get-DecimalOrZero $act["Nr. of statutory working hours"] }
            $actDays   = Get-DecimalOrZero $r["Nr. of actual working days"];     if ($actDays -eq 0)   { $actDays   = Get-DecimalOrZero $act["Nr. of actual working days"] }
            $actHours  = Get-DecimalOrZero $r["Nr. of actual working hrs"];      if ($actHours -eq 0)  { $actHours  = Get-DecimalOrZero $act["Nr. of actual working hrs"] }

            # Monthly base from yearly (if you store yearly)
            $baseYearLocal = 12 * $baseSalaryLocal
            $baseYearEUR   = 12 * $baseSalaryEUR
            $monthlyBaseLocal = $baseSalaryLocal
            $monthlyBaseEUR   = $baseSalaryEUR

            # Pro-rata base for actual days
            $baseForActualLocal = 0
            $baseForActualEUR   = 0
            if ($statDays -gt 0) {
                $baseForActualLocal = [decimal]$monthlyBaseLocal * ([decimal]$actDays / [decimal]$statDays)
                $baseForActualEUR   = [decimal]$monthlyBaseEUR   * ([decimal]$actDays / [decimal]$statDays)
            }

            # Sector counts (from Activity_Log or 0)
            $nrS   = Get-DecimalOrZero $act["Nr_S"]
            $nrM   = Get-DecimalOrZero $act["Nr_M"]
            $nrL   = Get-DecimalOrZero $act["Nr_L"]
            $nrXL  = Get-DecimalOrZero $act["Nr_XL"]
            $nrXXL = Get-DecimalOrZero $act["Nr_XXL"]
            $nrOffice = Get-DecimalOrZero $act["Nr_OfficeSectors"]
            $nrExtra  = Get-DecimalOrZero $act["Nr_ExtraSectors"]

            # Sector rates
            $rateS   = SectorRate $sectorRateIndex "S"
            $rateM   = SectorRate $sectorRateIndex "M"
            $rateL   = SectorRate $sectorRateIndex "L"
            $rateXL  = SectorRate $sectorRateIndex "XL"
            $rateXXL = SectorRate $sectorRateIndex "XXL"
            $rateOffice = SectorRate $sectorRateIndex "Office"
            $rateExtra  = SectorRate $sectorRateIndex "Extra"

            # Sector pays
            $payS   = $nrS   * $rateS
            $payM   = $nrM   * $rateM
            $payL   = $nrL   * $rateL
            $payXL  = $nrXL  * $rateXL
            $payXXL = $nrXXL * $rateXXL
            $payOffice = $nrOffice * $rateOffice
            $payExtra  = $nrExtra  * $rateExtra
            $totalSectorPay = $payS + $payM + $payL + $payXL + $payXXL + $payOffice + $payExtra

            # Distance & landing
            $km       = Get-DecimalOrZero $act["Kilometres"]
            $landings = Get-DecimalOrZero $act["Landings"]
            $rateDistance = Rate $ratesMiscIndex "DistanceRate" 0
            $rateLanding  = Rate $ratesMiscIndex "LandingRate"  0
            $distancePayLocal = $km * $rateDistance
            $landingPayLocal  = $landings * $rateLanding

            # Office duty categories
            $cat1 = Get-DecimalOrZero $act["OfficeDutyCat1"]
            $cat2 = Get-DecimalOrZero $act["OfficeDutyCat2"]
            $cat3 = Get-DecimalOrZero $act["OfficeDutyCat3"]
            $cat4 = Get-DecimalOrZero $act["OfficeDutyCat4"]
            $cat5 = Get-DecimalOrZero $act["OfficeDutyCat5"]

            $cat1Pay = $cat1 * (OfficeRate $officeRateIndex 1)
            $cat2Pay = $cat2 * (OfficeRate $officeRateIndex 2)
            $cat3Pay = $cat3 * (OfficeRate $officeRateIndex 3)
            $cat4Pay = $cat4 * (OfficeRate $officeRateIndex 4)
            $cat5Pay = $cat5 * (OfficeRate $officeRateIndex 5)
            $totalOfficeDutyPay = $cat1Pay + $cat2Pay + $cat3Pay + $cat4Pay + $cat5Pay

            # DA (per diem etc.) – simple: count * per-diem-rate
            $daAdvanceCount = Get-DecimalOrZero $act["Nr_DA_Advance"]
            $daBalanceCount = Get-DecimalOrZero $act["Nr_DA_Balance"]
            $daFCCount      = Get-DecimalOrZero $act["Nr_DA_FlightCrew"]

            $perDiemLocal = PerDiemForBase $perDiemIndex $base $fx
            $daAdvancePay = $daAdvanceCount * $perDiemLocal
            $daBalancePay = $daBalanceCount * $perDiemLocal
            $daFCPay      = $daFCCount      * $perDiemLocal

            # Commission & Mentoring & Loyalty (pull if present, else use rates or 0)
            $commissionLocal = Get-DecimalOrZero $r["Commission, local currency"]
            if ($commissionLocal -eq 0) {
                $pct = Rate $ratesMiscIndex "CommissionRate" 0
                if ($pct -gt 0) { $commissionLocal = [decimal]$totalCompLocal * ([decimal]$pct / 100) }
            }
            $mentoringLocal = Get-DecimalOrZero $r["Mentoring allowance, local currency"]
            if ($mentoringLocal -eq 0) { $mentoringLocal = Rate $ratesMiscIndex "MentoringMonthly" 0 }

            $pilotLoyaltyLocal = Get-DecimalOrZero $r["Pilot loyalty bonus, local currency"]
            if ($pilotLoyaltyLocal -eq 0) { $pilotLoyaltyLocal = Rate $ratesMiscIndex "PilotLoyaltyBonus" 0 }

            # Holidays / sick / maternity (counts may come from act or remain 0)
            $sickEmpDays   = Get-DecimalOrZero $act["Nr_SickDays_Emp"]
            $sickStateDays = Get-DecimalOrZero $act["Nr_SickDays_State"]
            $maternityDays = Get-DecimalOrZero $act["Nr_MaternityDays"]
            $holidayDays   = Get-DecimalOrZero $act["Nr_HolidayDays"]

            # For now, pays = 0 unless you give rates/formulas (we can plug later)
            $sickPayLocal = 0
            $maternityPayLocal = 0
            $holidayPayLocal = 0
            $otherHolidayDays = Get-DecimalOrZero $act["Nr_OtherHoliday"]
            $otherHolidayPayLocal = 0

            # Totals (illustrative – adjust as needed)
            $totalGrossLocal =
                $baseForActualLocal +
                $totalSectorPay +
                $distancePayLocal + $landingPayLocal +
                $totalOfficeDutyPay +
                $daAdvancePay + $daBalancePay + $daFCPay +
                $commissionLocal + $mentoringLocal + $pilotLoyaltyLocal +
                $sickPayLocal + $maternityPayLocal + $holidayPayLocal + $otherHolidayPayLocal

            $totalGrossEUR = if ($fx -gt 0) { [decimal]$totalGrossLocal / [decimal]$fx } else { 0 }

            # Taxes/contributions (placeholders until we inject country logic)
            $personalIncomeTaxLocal = Get-DecimalOrZero $r["Personal Income Tax, local currency"]
            $employeeContribLocal   = Get-DecimalOrZero $r["Total Employee contributions, local currency"]
            $employerContribLocal   = Get-DecimalOrZero $r["Total Employer contributions, local currency"]

            $netSalaryLocal = $totalGrossLocal - $personalIncomeTaxLocal - $employeeContribLocal
            $netSalaryEUR   = if ($fx -gt 0) { [decimal]$netSalaryLocal / [decimal]$fx } else { 0 }

            # Write row in exact order
            $values = @(
                $payrollMonth, $empId, $name, $r["Start date at the branch"], $r["Exit date"], $company, $base, $costCtr, $position, [string]$fx,
                [string]$baseYearEUR, [string]$baseYearLocal, [string]$monthlyBaseEUR, [string]$monthlyBaseLocal,
                [string]$sickEmpDays, [string]$sickStateDays, [string]$sickPayLocal,
                [string]$maternityDays, [string]$maternityPayLocal, [string]$holidayDays, [string]$holidayPayLocal,
                [string]$otherHolidayDays, [string]$otherHolidayPayLocal, [string](Get-DecimalOrZero $act["Nr_UnpaidLeave"]), [string](Get-DecimalOrZero $act["Nr_UnjustifiedAbsence"]),
                [string](Get-DecimalOrZero $act["Nr_PublicHoliday"]), [string]0, [string]$statDays, [string]$statHours,
                [string]$actDays, [string]$actHours, [string]$baseForActualLocal, [string]$baseForActualEUR,
                [string]$totalCompLocal, [string]$nrS, [string]$payS, [string]$nrM, [string]$payM,
                [string]$nrL, [string]$payL, [string]$nrXL, [string]$payXL, [string]$nrXXL, [string]$payXXL,
                [string]$nrOffice, [string]$payOffice, [string]$nrExtra, [string]$payExtra, [string]$totalSectorPay,
                [string]$commissionLocal, [string]$mentoringLocal, [string]$daAdvanceCount, [string]$daAdvancePay,
                [string]$daBalanceCount, [string]$daBalancePay, [string]$daFCCount, [string]$daFCPay,
                [string]$km, [string]$distancePayLocal, [string]$landings, [string]$landingPayLocal,
                [string]$cat1, [string]$cat1Pay, [string]$cat2, [string]$cat2Pay,
                [string]$cat3, [string]$cat3Pay, [string]$cat4, [string]$cat4Pay,
                [string]$cat5, [string]$cat5Pay, [string]$totalOfficeDutyPay,
                [string](Get-DecimalOrZero $act["Nr_ExtraFlyingDuties"]), [string]0, [string](Get-DecimalOrZero $act["Nr_OutOfBaseDuties"]), [string]0,
                [string](Get-DecimalOrZero $act["Nr_LineTrainingSectors"]), [string]0, [string](Rate $ratesMiscIndex "FlexibleRosterAllowance" 0), [string]$pilotLoyaltyLocal,
                [string](Rate $ratesMiscIndex "NightTransportation" 0), [string](Rate $ratesMiscIndex "PeopleCouncil" 0), [string](Rate $ratesMiscIndex "AllEmployeeBonus" 0), [string](Rate $ratesMiscIndex "RelocationSupport" 0),
                [string](Get-DecimalOrZero $r["One time payment, local currency"]), [string](Get-DecimalOrZero $r["Correction"]), [string](Get-DecimalOrZero $r["Nr of remaining holidays"]), [string](Get-DecimalOrZero $r["Remaining holiday payment, local currency"]),
                [string](Get-DecimalOrZero $r["Disrupted Roster Compensation, local currency"]), [string](Get-DecimalOrZero $act["Nr_FlyingDutyDays"]), [string]0, [string]0,
                [string]0, [string]0, [string](if ($fx -gt 0) { [decimal]$commissionLocal / [decimal]$fx } else { 0 }), [string](if ($fx -gt 0) { [decimal]$distancePayLocal / [decimal]$fx } else { 0 }), [string](if ($fx -gt 0) { [decimal]$landingPayLocal / [decimal]$fx } else { 0 }), [string]$r["Pilot Ranking"],
                [string]$totalGrossLocal, [string]$totalGrossEUR, [string]$personalIncomeTaxLocal, [string]$employeeContribLocal,
                [string]$employerContribLocal, [string](if ($fx -gt 0) { ([decimal]$employerContribLocal + [decimal]$totalGrossLocal) / [decimal]$fx } else { 0 }),
                [string]([decimal]$employerContribLocal + [decimal]$totalGrossLocal), [string]$netSalaryEUR, [string]$netSalaryLocal,
                [string]$netSalaryEUR, [string]$netSalaryLocal, [string]0, [string]0, [string]$netSalaryLocal, [string]$r["Comments"],
                [string](Rate $ratesMiscIndex "CountryManagerAllowance" 0), [string](Rate $ratesMiscIndex "SeniorityBonus" 0), [string](Get-DecimalOrZero $r["Interim Tax Correction, local currency"]), [string]0, [string]0,
                [string]0,[string]0,[string]0,[string]0,[string]0,[string]0,
                [string]0,[string]0,[string]0,[string](Get-DecimalOrZero $r["Loss of Licence, local currency"]),[string]0,[string]0,
                [string]0,[string]0,[string]0,[string]0,[string]0,[string]0,[string]$r["AC"],[string]$r["POS"],[string](Get-DecimalOrZero $r["Block Hours"]),
                [string]$r["CONTRACT TYPE"],[string](Get-DecimalOrZero $act["TOTAL NUMBER OF DUTY DAYS"]),[string](Get-DecimalOrZero $act["NIGHT FLIGHT ALLOWANCE (COUNT)"]),[string](Get-DecimalOrZero $act["NIGHT FLIGHT ALLOWANCE (EUR)"]),
                [string](Get-DecimalOrZero $act["DA ADVANCED"]),[string](Get-DecimalOrZero $act["DA advance amount"]),[string](Get-DecimalOrZero $act["DA BALANCE"]),
                [string]$payXXL,[string]$payXL,[string]$payL,[string]$payM,[string]$payS,[string]$totalSectorPay,
                [string]0,[string]0,[string]0,[string]0,[string]0,
                [string]0,[string]0,[string]0,[string]0,[string]0,[string]$totalOfficeDutyPay,
                [string]$commissionLocal,[string]"LOCAL",[string](Rate $ratesMiscIndex "Mentoring6mEUR" 0),[string](Rate $ratesMiscIndex "Mentoring12mEUR" 0),
                [string](Rate $ratesMiscIndex "MentoringTotalEUR" 0),[string](Get-DecimalOrZero $act["CAPTAIN FLOWN HOURS"]),[string](Get-DecimalOrZero $act["TOTAL KM"]),
                [string](Get-DecimalOrZero $act["KM INTERNATIONAL"]),[string](Get-DecimalOrZero $act["KM DOMESTIC"]),[string](Get-DecimalOrZero $act["FLOWN DUTY DAYS TOTAL"]),
                [string](Get-DecimalOrZero $act["TOTAL NR OF FLOWN LANDINGS"]),
                [string]$cat5,[string]$cat4,[string]$cat3,[string]$cat2,[string]$cat1,[string](Get-DecimalOrZero $act["EXTRA FLYING DUTIES"]),
                [string](Get-DecimalOrZero $act["FLYING FROM OFF / HP"]),[string](Get-DecimalOrZero $act["DAILY ALLOWANCE"]),
                [string](Get-DecimalOrZero $act["LINE TRAINING SECTORS"]),
                [string](Get-DecimalOrZero $act["FLOATING PILOT ALLOWANCE"]),[string]$pilotLoyaltyLocal,[string](Get-DecimalOrZero $act["NIGHT FLIGHT ALLOWANCE (Count)2"]),
                [string](Get-DecimalOrZero $r["LOSS OF LICENCE"]),[string]$r["LOSS OF LICENCE TYPE"],
                [string](Rate $ratesMiscIndex "FLEXIBLE ROSTER" 0),[string](Rate $ratesMiscIndex "FLEXIBLE ROSTER CURRENCY" 0),
                [string](Rate $ratesMiscIndex "SIGN-ON BONUS" 0),[string](Rate $ratesMiscIndex "RETENTION BONUS" 0),[string](Get-DecimalOrZero $r["NUMBER OF AIRCRAFTS"])
            )

            # write the row
            for ($c=0; $c -lt $outputColumns.Count; $c++) {
                $wsOut.Cells.Item($rowOut, $c+1) = $values[$c]
            }
            $rowOut++
        }

        # autosize
        $wsOut.UsedRange.Columns.AutoFit() | Out-Null
        $wb.Save()
    }
    finally {
        if ($wb) { $wb.Close($true) }
        $excel.Quit()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
    }

    Write-Output "Output sheet built successfully."
}

Export-ModuleMember -Function New-PayrollOutput