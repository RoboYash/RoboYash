function Clear-ConsolidationSheet {
    <#
    .SYNOPSIS
        Clears data from the "Consolidation" sheet in the payroll workbook.

    .DESCRIPTION
        - Opens the Excel workbook
        - Finds the "Consolidation" sheet
        - Clears all used cells except the first row (headers stay intact)
        - Saves and closes the workbook

    .PARAMETER WorkbookPath
        Full path to the payroll Excel workbook.

    .EXAMPLE
        Clear-ConsolidationSheet -WorkbookPath "C:\PayrollAutomation\Payroll.xlsx"
    #>

    param(
        [Parameter(Mandatory=$true)][string]$WorkbookPath
    )

    # Start Excel COM object
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    try {
        # Open the workbook
        $workbook = $excel.Workbooks.Open($WorkbookPath)

        # Get the "Consolidation" worksheet
        $sheet = $workbook.Sheets | Where-Object { $_.Name -eq "Consolidation" }
        if (-not $sheet) {
            throw "Sheet 'Consolidation' not found in $WorkbookPath"
        }

        # Identify used range (all filled cells)
        $usedRange = $sheet.UsedRange

        if ($usedRange.Rows.Count -gt 1) {
            # Clear everything except the first row (header row)
            $rowsToClear = $sheet.Range("A2", $sheet.Cells.Item($usedRange.Rows.Count, $usedRange.Columns.Count))
            $rowsToClear.ClearContents()
        }

        # Save changes
        $workbook.Save()
    }
    finally {
        # Cleanup Excel COM objects
        $workbook.Close($true)
        $excel.Quit()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($sheet)   | Out-Null
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook)| Out-Null
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)   | Out-Null
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}
  