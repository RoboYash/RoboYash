﻿cd C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation
.\run_AddPayrollMonth.ps1 -WorkbookPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx" -PayrollMonth "2025-08"






# Load the master module
Import-Module .\PayrollAutomation.psm1 -Force

# Run the full process
Run-PayrollProcess -ExcelPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx"