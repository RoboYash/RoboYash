﻿# Import the module
Import-Module .\AddPayrollMonthColumn.psm1 -Force

# Run the function
Add-PayrollMonthColumn -ExcelPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx" -PayrollMonth "August 2025"