﻿# Go to project folder
cd C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\

# Import Module4
Import-Module .\TransformTableUsingMap.psm1 -Force

# Call function
Transform-TableUsingMap -ExcelPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx"