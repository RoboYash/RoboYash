﻿cd C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation

# Import Module5
Import-Module .\AddCalculatedColumnToOutput.psm1 -Force

# Run calculated columns step
Add-CalculatedColumnToOutput -ExcelPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx"