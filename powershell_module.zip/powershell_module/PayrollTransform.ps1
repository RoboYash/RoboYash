param(
    [string]$ExcelPath = "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx"
)

Import-Module "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\TransformTableUsingMap.psm1"

# --- Step 1: Transform Raw Data ---
$transformedData = Transform-TableUsingMap -ExcelPath $ExcelPath

# --- Step 2: Add Custom/VBA-Equivalent Columns ---
$enhancedData = $transformedData | ForEach-Object {
    $row = $_

    # replicate VBA-calculated fields
    [PSCustomObject]@{
        Employee_Name     = $row.Employee_Name
        Department        = $row.Department
        Base_Salary       = $row.Base_Salary
        Bonus_Amount      = $row.Bonus_Amount
        Date_Of_Joining   = $row.Date_Of_Joining
        TotalCompensation = $row.Base_Salary + $row.Bonus_Amount
        NetPay            = $row.Base_Salary + $row.Bonus_Amount  # we will refine logic
        PayrollMonth      = (Get-Date -Format "MMMM yyyy")

        # EXTRA fields from VBA
        YearsOfService    = ((Get-Date) - $row.Date_Of_Joining).Days / 365
        Grade             = if ($row.Base_Salary -gt 50000) { "A" } else { "B" }
        Remarks           = if ($row.Department -eq "HR") { "Support" } else { "Core" }
    }
}

# --- Step 3: Write back to a sheet that PAD will use ---
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$wb = $excel.Workbooks.Open($ExcelPath)

# clear or create Output sheet
try { $ws = $wb.Sheets("Output") } catch { $ws = $wb.Sheets.Add(); $ws.Name = "Output" }
$ws.Cells.Clear()

# write headers
$headers = $enhancedData[0].psobject.Properties.Name
for ($i=0; $i -lt $headers.Count; $i++) {
    $ws.Cells.Item(1, $i+1) = $headers[$i]
}

# write data
$rowIndex = 2
foreach ($row in $enhancedData) {
    $colIndex = 1
    foreach ($val in $row.PSObject.Properties.Value) {
        $ws.Cells.Item($rowIndex, $colIndex) = $val
        $colIndex++
    }
    $rowIndex++
}

$wb.Save()
$wb.Close($true)
$excel.Quit()

Write-Output "Output sheet populated successfully"