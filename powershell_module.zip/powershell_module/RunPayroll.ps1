﻿<#
.SYNOPSIS
    Runner script to execute the entire Payroll Automation process.

.DESCRIPTION
    This script loads PayrollAutomation.psm1 and runs the Run-PayrollAutomation
    function with required parameters. It will:
      - Read Input Excel
      - Transform & clean data
      - Add payroll month & calculated columns
      - Upload final data to SQL
      - Export processed payroll report from SQL to Excel
#>

# Ensure the module path is correct (update if needed)
$ModulePath = "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\PayrollAutomation.psm1"

# Import the PayrollAutomation module
Import-Module $ModulePath -Force

# Define parameters
$InputFilePath = "C:\IMVP64-Payroll_File_Consolidation\Input\Payroll_Input.xlsx"
$ConsolidationFilePath = "C:\IMVP64-Payroll_File_Consolidation\Output\Payroll_Consolidated.xlsx"
$SqlServer = "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS"                  # Change to your SQL Server name if different
$Database = "WizzAir.GTN-RAW"                   # Your existing database
$TableName = "PayrollData"                # Table to store payroll records
$ExportPath = "C:\IMVP64-Payroll_File_Consolidation\Output\Payroll_Report.xlsx"

# Run Payroll Automation
Run-PayrollAutomation `
    -InputFilePath $InputFilePath `
    -ConsolidationFilePath $ConsolidationFilePath `
    -SqlServer $SqlServer `
    -Database $Database `
    -TableName $TableName `
    -ExportPath $ExportPath