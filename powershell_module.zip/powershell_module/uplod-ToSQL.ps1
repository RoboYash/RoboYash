﻿Import-Module .\Upload-ToSQL.psm1 -Force

Upload-ToSQL `
    -ExcelPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll.xlsx" `
    -SheetName "FinalOutputWithMonth" `
    -SqlServer "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS" `
    -Database "WizzAir.GTN-RAW" `
    -TableName "PayrollFinal" `
    -Append