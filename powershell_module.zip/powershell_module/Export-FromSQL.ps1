﻿Import-Module "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Export-FromSQL.psm1" -Force
Export-FromSQL `
    -SqlServer "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS" `
    -Database "WizzAir.GTN-RAW" `
    -TableName "PayrollData" `
    -ExportPath "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation\Payroll_Report_Test.xlsx"



Invoke-Sqlcmd -ServerInstance "UAVODPXSQLHRS01.UAT-WIZZAIR.LOCAL\HRS" -Database "WizzAir.GTN-RAW" -Query "SELECT TOP 5 * FROM PayrollData"

$excel = New-Object -ComObject Excel.Application
$excel.Quit()


Test-Path "C:\IMVP64-Payroll_File_Consolidation\PayrollAutomation"